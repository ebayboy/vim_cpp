#!/bin/bash

# ***************************************************************************
# * 
# * @file:build_cpp_tags.sh 
# * @author:ebayboy@163.com 
# * @date:2019-11-18 18:54 
# * @version 1.0  
# * @description: Shell script 
# * @Copyright (c)  all right reserved 
#* 
#**************************************************************************/ 

ctags -R --c++-kinds=+p --fields=+iaS --extra=+q --language-force=C++ ./ -R

mv tags ~/cpp

#set tags+=~/cpp

exit 0

